Список товаров
/products/

Список товаров по id
/products/1,2,3/

Выбор полей
/products/?fields=id,name,body,position,created,images,variants,categories

Присоединение связанных данных
/products/?fields=images,variants,categories

!Сортировка
/products/?order=name


!Количество
/products/count/

!Сортировка
/products/?order=name

!Постраничность
/products/?page=5&limit=10


По категориям
/categories/3/products

!По брендам
/brands/7/products

