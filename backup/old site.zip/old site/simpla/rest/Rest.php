<?php

require_once('../../api/Simpla.php');

class Rest extends Simpla
{	

}

