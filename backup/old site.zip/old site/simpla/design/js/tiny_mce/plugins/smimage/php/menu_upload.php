<ul>
	<?php
	echo "<li><a id=\"m12\" href=\"javascript:;\" title=\"\" onclick=\"window.location.href='index.php?get=".bin2hex(RC4("id=1&".$GET))."'; if (window.event){ window.event.returnValue = false; }\"><img src=\"img/icon_image_24x24.png\" border=\"0\" /></a></li>";
	echo "<li><img class=\"separator\" src=\"img/icon_separator.png\" border=\"0\" /></li>";
	?>
</ul>