var settings = {
    container: null
    , tabs: null


};

$(function(){

    settings.container = $('#settings-page');

    if (!settings.container.length) {
        return false;
    }

    /*translate.tabs = $('#settingsTab');*/
});