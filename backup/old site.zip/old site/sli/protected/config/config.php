<?php
return array(
    'db' => array(
        'host' => 'localhost',
        'database' => 'amf_ulafua',
        'username' => 'u_amf_ulafua',
        'password' => '4T41C86T',
        'encoding' => 'utf8',
    ),
    'memcache' => array(
        'host' => '127.0.0.1',
        'port' => '11211',
    ),
);