<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * DF Social Count Twitch Counter.
 *
 * @package  DF_Social_Count/Twitch_Counter
 * @category Counter
 * @author   Dan Fisher
 */
class DF_Social_Count_Twitch_Counter extends DF_Social_Count_Counter {

	/**
	 * Counter ID.
	 *
	 * @var string
	 */
	public $id = 'twitch';

	/**
	 * API URL.
	 *
	 * @var string
	 */
	protected $api_url = 'https://api.twitch.tv/helix/';

	/**
	 * OAuth token URL
	 *
	 * OAuth Client Credentials Flow:
	 * https://dev.twitch.tv/docs/authentication/
	 *
	 * @var string
	 */
	protected $token_url = 'https://id.twitch.tv/oauth2/token';

	/**
	 * Client ID.
	 *
	 * @var string
	 */
	protected $client_id;

	/**
	 * Client Secret.
	 *
	 * @var string
	 */
	protected $client_secret;

	/**
	 * Constructor.
	 */
	public function __construct() {

		$options = get_option( 'dfsocialcount_settings' );

		$this->client_id = ( ! empty ( $options['twitch_client_ID'] ) ) ? esc_html( $options['twitch_client_ID'] ) : '';

		$this->client_secret = ( ! empty ( $options['twitch_client_secret'] ) ) ? esc_html( $options['twitch_client_secret'] ) : '';
	}

	/**
	 * Test the counter is available.
	 *
	 * @param  array $settings Plugin settings.
	 *
	 * @return bool
	 */
	public function is_available( $settings ) {
		return isset( $settings['twitch_active'] ) && ! empty( $settings['twitch_username'] ) && ! empty( $settings['twitch_user_ID'] ) && ! empty( $settings['twitch_client_ID'] ) && ! empty( $settings['twitch_client_secret'] );
	}

	/**
	 * Get the total.
	 *
	 * @param  array $settings Plugin settings.
	 * @param  array $cache    Counter cache.
	 *
	 * @return int
	 */
	public function get_total( $settings, $cache ) {
		if ( $this->is_available( $settings ) ) {

			$token = $this->get_token();

			$params = array(
				'timeout' => 60,
				'headers' => array(
					'Client-ID' => $settings['twitch_client_ID'],
					'Authorization' => 'Bearer ' . base64_decode( $token )
				)
			);
			
			$this->connection = wp_remote_get( esc_url_raw( $this->api_url . 'users/follows?to_id=' . $settings['twitch_user_ID'] ), $params );

			if ( is_wp_error( $this->connection ) || ( isset( $this->connection['response']['code'] ) && 200 != $this->connection['response']['code'] ) ) {
				$this->total = ( isset( $cache[ $this->id ] ) ) ? $cache[ $this->id ] : 0;
			} else {
				$_data = json_decode( $this->connection['body'], true );

				if ( isset( $_data['total'] ) ) {
					$count = intval( $_data['total'] );

					$this->total = $count;
				} else {
					$this->total = ( isset( $cache[ $this->id ] ) ) ? $cache[ $this->id ] : 0;
				}
			}
		}

		return $this->total;
	}

	/**
	 * Get OAuth token
	 *
	 * @return bool|string
	 */
	private function get_token() {

		$token = get_transient( 'df_twitch_token' );

		if ( false !== $token ) {
			return $token;
		}

		$args = [
			'client_id' => $this->client_id,
			'client_secret' => $this->client_secret,
			'grant_type' => 'client_credentials'
		];

		$headers = [
			'Content-Type' => 'application/json'
		];

		$response = wp_remote_post( $this->token_url, [
			'headers' => $headers,
			'body'    => wp_json_encode( $args ),
			'timeout' => 15
		]);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$result = wp_remote_retrieve_body( $response );

		$result = json_decode( $result, true );

		/**
		 * Additionally we can validate token for debugging:
		 * curl -H "Authorization: OAuth <access_token>" https://id.twitch.tv/oauth2/validate
		 *
		 * response example:
		 * {"client_id":"1cphbefbx1lbtyfvzx3ja268226w7y","scopes":[],"expires_in":5445171}
		 */
		$this->debug( $result, 'TP_Twitch_API->get_token >> $token' );

		if ( $result === false || ! isset( $result['access_token'] ) )
			return false;

		$token = base64_encode( $result['access_token'] );

		set_transient( 'df_twitch_token', $token, $result['expires_in'] - 30 );

		return $token;
	}

	/**
	 * Get conter view.
	 *
	 * @param  array  $settings   Plugin settings.
	 * @param  int    $total      Counter total.
	 *
	 * @return string
	 */
	public function get_view( $settings, $total ) {
		$twitch_username = ! empty( $settings['twitch_username'] ) ? $settings['twitch_username'] : '';
		$twitch_txt      = ! empty( $settings['twitch_txt'] ) ? $settings['twitch_txt'] : __( 'Twitch', 'df-social-count' );

		return $this->get_view_item( 'https://www.twitch.tv/' . $twitch_username . '/profile', $total, __( 'followers', 'df-social-count' ), $twitch_txt, $settings );
	}
}
