<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * DF Social Count VK Counter.
 *
 * @package  DF_Social_Count/VK_Counter
 * @category Counter
 * @author   Dan Fisher
 */
class DF_Social_Count_Vk_Counter extends DF_Social_Count_Counter {

	/**
	 * Counter ID.
	 *
	 * @var string
	 */
	public $id = 'vk';

	/**
	 * API URL.
	 *
	 * @var string
	 */
	protected $api_url = 'https://api.vk.com/method';

	/**
	 * Test the counter is available.
	 *
	 * @param  array $settings Plugin settings.
	 *
	 * @return bool
	 */
	public function is_available( $settings ) {
		return isset( $settings['vk_active'] ) && ! empty( $settings['vk_group_id'] ) && ! empty( $settings['vk_token'] );
	}

	/**
	 * Get the total.
	 *
	 * @param  array $settings Plugin settings.
	 * @param  array $cache    Counter cache.
	 *
	 * @return int
	 */
	public function get_total( $settings, $cache ) {
		if ( $this->is_available( $settings ) ) {
			$url = sprintf(
				'%s/groups.getById?group_id=%s&fields=members_count&v=5.126&access_token=%s',
				$this->api_url,
				sanitize_text_field( $settings['vk_group_id'] ),
				sanitize_text_field( $settings['vk_token'] )
			);

			$this->connection = wp_remote_get( $url, array( 'timeout' => 60 ) );

			if ( is_wp_error( $this->connection ) || ( isset( $this->connection['response']['code'] ) && 200 != $this->connection['response']['code'] ) ) {
				$this->total = ( isset( $cache[ $this->id ] ) ) ? $cache[ $this->id ] : 0;
			} else {
				$_data = json_decode( $this->connection['body'], true );

				if ( isset( $_data['response'][0]['members_count'] ) ) {
					$count = intval( $_data['response'][0]['members_count'] );

					$this->total = $count;
				} else {
					$this->total = ( isset( $cache[ $this->id ] ) ) ? $cache[ $this->id ] : 0;
				}
			}
		}

		return $this->total;
	}

	/**
	 * Get conter view.
	 *
	 * @param  array  $settings   Plugin settings.
	 * @param  int    $total      Counter total.
	 *
	 * @return string
	 */
	public function get_view( $settings, $total ) {
		$vk_url = ! empty( $settings['vk_url'] ) ? $settings['vk_url'] : '';
		$vk_txt = ! empty( $settings['vk_txt'] ) ? $settings['vk_txt'] : __( 'VK', 'df-social-count' );

		return $this->get_view_item( $vk_url, $total, __( 'members', 'df-social-count' ), $vk_txt, $settings );
	}
}
