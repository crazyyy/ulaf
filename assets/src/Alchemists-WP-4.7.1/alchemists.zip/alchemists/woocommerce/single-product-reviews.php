<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.7.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}

$reviews_classes = array( 'comments' );
if ( alchemists_sp_preset('football') ) {
	$reviews_classes[] = 'comments--thumb-top';
} elseif ( alchemists_sp_preset( 'esports' ) ) {
	$reviews_classes[] = 'comments--thumb-top';
} else {
	$reviews_classes[] = 'comments--left-thumb';
}

$product_header_classes = array( 'product-tabs__header' );
if ( alchemists_sp_preset( 'esports' ) ) {
	$product_header_classes[] = 'product-tabs__header--sm';
}

?>
<div id="reviews" class="woocommerce-Reviews">
	<div id="comments">
		<header class="<?php echo esc_attr( implode( ' ', $product_header_classes ) ); ?>">
			<h2 class="woocommerce-Reviews-title">
				<?php
				$count = $product->get_review_count();
				if ( $count && wc_review_ratings_enabled() ) {
					/* translators: 1: reviews count 2: product name */
					$reviews_title = sprintf( esc_html( _n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'alchemists' ) ), esc_html( $count ), '<span>' . get_the_title() . '</span>' );
					echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product ); // WPCS: XSS ok.
				} else {
					esc_html_e( 'Reviews', 'alchemists' );
				}
				?>
			</h2>
		</header>

		<?php if ( have_comments() ) : ?>

			<ol class="<?php echo esc_attr( implode( ' ', $reviews_classes ) ); ?>">
				<?php wp_list_comments( apply_filters( 'woocommerce_product_review_list_args', array( 'callback' => 'woocommerce_comments' ) ) ); ?>
			</ol>

			<?php
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
				echo '<nav class="woocommerce-pagination">';
				paginate_comments_links(
					apply_filters(
						'woocommerce_comment_pagination_args',
						array(
							'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
							'next_text' => is_rtl() ? '&larr;' : '&rarr;',
							'type'      => 'list',
						)
					)
				);
				echo '</nav>';
			endif;
			?>
		<?php else : ?>

			<div class="alert alert-info woocommerce-noreviews"><strong><?php esc_html_e( 'There are no reviews yet.', 'alchemists' ); ?></strong></div>

		<?php endif; ?>
	</div>

	<?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
		<div id="review_form_wrapper">
			<div id="review_form">
				<?php
					$commenter    = wp_get_current_commenter();
					$comment_form = array(
						/* translators: %s is product title */
						'title_reply'         => have_comments() ? esc_html__( 'Add a review', 'alchemists' ) : sprintf( esc_html__( 'Be the first to review &ldquo;%s&rdquo;', 'alchemists' ), get_the_title() ),
						/* translators: %s is product title */
						'title_reply_to'      => esc_html__( 'Leave a Reply to %s', 'alchemists' ),
						'title_reply_before'  => '<header class="product-tabs__header"><h2 id="reply-title" class="comment-reply-title">',
						'title_reply_after'   => '</h2></header>',
						'comment_notes_before'=> '',
						'comment_notes_after' => '',
						'label_submit'        => esc_html__( 'Submit', 'alchemists' ),
						'logged_in_as'        => '',
						'comment_field'       => '',
					);

					$name_email_required = (bool) get_option( 'require_name_email', 1 );
					$fields              = array(
						'author' => array(
							'label'    => esc_html__( 'Name', 'alchemists' ),
							'type'     => 'text',
							'value'    => $commenter['comment_author'],
							'required' => $name_email_required,
							'before'   => '<div class="row"><div class="col-lg-6"><div class="form-group comment-form-author">',
							'after'    => '</div></div>',
							'autocomplete' => 'name',
						),
						'email'  => array(
							'label'    => esc_html__( 'Email', 'alchemists' ),
							'type'     => 'email',
							'value'    => $commenter['comment_author_email'],
							'required' => $name_email_required,
							'before'   => '<div class="col-lg-6"><div class="form-group comment-form-email">',
							'after'    => '</div></div></div>',
							'autocomplete' => 'email',
						),
					);

					$comment_form['fields'] = array();

					foreach ( $fields as $key => $field ) {
						$field_html  = $field['before'];
						$field_html .= '<p class="comment-form-' . esc_attr( $key ) . '">';
						$field_html .= '<label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] );

						if ( $field['required'] ) {
							$field_html .= '&nbsp;<span class="required">*</span>';
						}

						$field_html .= '</label><input id="' . esc_attr( $key ) . '" class="form-control" name="' . esc_attr( $key ) . '" type="' . esc_attr( $field['type'] ) . '" autocomplete="' . esc_attr( $field['autocomplete'] ) . '" value="' . esc_attr( $field['value'] ) . '" size="30" ' . ( $field['required'] ? 'required' : '' ) . ' /></p>';

						$field_html .= $field['after'];

						$comment_form['fields'][ $key ] = $field_html;
					}

					$account_page_url = wc_get_page_permalink( 'myaccount' );
					if ( $account_page_url ) {
						/* translators: %s opening and closing link tags respectively */
						$comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf( esc_html__( 'You must be %1$slogged in%2$s to post a review.', 'alchemists' ), '<a href="' . esc_url( $account_page_url ) . '">', '</a>' ) . '</p>';
					}

					if ( wc_review_ratings_enabled() ) {
						$comment_form['comment_field'] = '<div class="form-group"><label for="rating" class="control-label">' . esc_html__( 'Your rating', 'alchemists' ) . ( wc_review_ratings_required() ? '&nbsp;<span class="required">*</span>' : '' ) . '</label><select name="rating" id="rating" class="form-control" required>
							<option value="">' . esc_html__( 'Rate&hellip;', 'alchemists' ) . '</option>
							<option value="5">' . esc_html__( '5 Stars - Perfect', 'alchemists' ) . '</option>
							<option value="4">' . esc_html__( '4 Stars - Good', 'alchemists' ) . '</option>
							<option value="3">' . esc_html__( '3 Stars - Average', 'alchemists' ) . '</option>
							<option value="2">' . esc_html__( '2 Stars - Not that bad', 'alchemists' ) . '</option>
							<option value="1">' . esc_html__( '1 Star - Very poor', 'alchemists' ) . '</option>
						</select></div>';
					}

					$comment_form['comment_field'] .= '<div class="form-group comment-form-comment"><label for="comment">' . esc_html__( 'Your review', 'alchemists' ) . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" class="form-control" cols="45" rows="8" required></textarea></div>';

					comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
				?>
			</div>
		</div>
	<?php else : ?>

		<div class="alert alert-warning mb-0 woocommerce-verification-required"><strong><?php esc_html_e( 'Only logged in customers who have purchased this product may leave a review.', 'alchemists' ); ?></strong></div>

	<?php endif; ?>

</div>
