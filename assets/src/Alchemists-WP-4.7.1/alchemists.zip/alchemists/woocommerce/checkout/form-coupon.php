<?php
/**
 * Checkout coupon form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-coupon.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.8.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) { // @codingStandardsIgnoreLine.
	return;
}

?>
<div class="woocommerce-form-coupon-toggle">
	<?php
		/**
		 * Filter checkout coupon message.
		 *
		 * @param string $message coupon message.
		 * @return string Filtered message.
		 *
		 * @since 1.0.0
		 */
		wc_print_notice( apply_filters( 'woocommerce_checkout_coupon_message', esc_html__( 'Have a coupon?', 'alchemists' ) . ' <a href="#" role="button" aria-label="' . esc_attr__( 'Enter your coupon code', 'alchemists' ) . '" aria-controls="woocommerce-checkout-form-coupon" aria-expanded="false" class="showcoupon">' . esc_html__( 'Click here to enter your code', 'alchemists' ) . '</a>' ), 'notice' );
	?>
</div>

<form class="checkout_coupon form-inline" method="post" style="display:none" id="woocommerce-checkout-form-coupon">

	<div class="card card--block">
		<div class="card__content">
			<div class="form-inline">
				<div class="input-group">
					<label for="coupon_code" class="screen-reader-text"><?php esc_html_e( 'Coupon:', 'alchemists' ); ?></label>
					<input type="text" name="coupon_code" class="input-text form-control" placeholder="<?php esc_attr_e( 'Coupon code', 'alchemists' ); ?>" id="coupon_code" value="" />
					<div class="input-group-append">
						<button type="submit" class="button btn-lg apply_coupon<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'alchemists' ); ?>"><?php esc_html_e( 'Apply coupon', 'alchemists' ); ?></button>
					</div>
				</div>
			</div>
		</div>
	</div>

</form>
